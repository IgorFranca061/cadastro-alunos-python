import json
import os

ARQUIVO = 'alunos.json'

def carregar_dados():
    if not os.path.exists(ARQUIVO):
        return []
    with open(ARQUIVO, 'r', encoding='utf-8') as f:
        return json.load(f)

def salvar_dados(alunos):
    with open(ARQUIVO, 'w', encoding='utf-8') as f:
        json.dump(alunos, f, indent=4, ensure_ascii=False)

def gerar_id(alunos):
    if not alunos:
        return 1
    return max(aluno['id'] for aluno in alunos) + 1

def incluir_aluno(alunos):
    nome = input("Nome: ")
    idade = int(input("Idade: "))
    curso = input("Curso: ")
    matricula = input("Matrícula: ")
    aluno = {
        "id": gerar_id(alunos),
        "nome": nome,
        "idade": idade,
        "curso": curso,
        "matricula": matricula
    }
    alunos.append(aluno)
    salvar_dados(alunos)
    print("Aluno incluído com sucesso!\n")

def listar_alunos(alunos):
    if not alunos:
        print("Nenhum aluno cadastrado.\n")
        return
    for aluno in alunos:
        print(f"ID: {aluno['id']}, Nome: {aluno['nome']}, Idade: {aluno['idade']}, Curso: {aluno['curso']}, Matrícula: {aluno['matricula']}")
    print()

def alterar_aluno(alunos):
    id_alvo = int(input("Informe o ID do aluno a ser alterado: "))
    for aluno in alunos:
        if aluno['id'] == id_alvo:
            aluno['nome'] = input(f"Novo nome ({aluno['nome']}): ") or aluno['nome']
            aluno['idade'] = int(input(f"Nova idade ({aluno['idade']}): ") or aluno['idade'])
            aluno['curso'] = input(f"Novo curso ({aluno['curso']}): ") or aluno['curso']
            aluno['matricula'] = input(f"Nova matrícula ({aluno['matricula']}): ") or aluno['matricula']
            salvar_dados(alunos)
            print("Aluno alterado com sucesso!\n")
            return
    print("Aluno não encontrado.\n")

def excluir_aluno(alunos):
    id_alvo = int(input("Informe o ID do aluno a ser excluído: "))
    for aluno in alunos:
        if aluno['id'] == id_alvo:
            alunos.remove(aluno)
            salvar_dados(alunos)
            print("Aluno excluído com sucesso!\n")
            return
    print("Aluno não encontrado.\n")

def menu():
    alunos = carregar_dados()
    while True:
        print("==== SISTEMA DE CADASTRO DE ALUNOS ====")
        print("1. Incluir aluno")
        print("2. Listar alunos")
        print("3. Alterar aluno")
        print("4. Excluir aluno")
        print("5. Sair")
        opcao = input("Escolha uma opção: ")

        if opcao == '1':
            incluir_aluno(alunos)
        elif opcao == '2':
            listar_alunos(alunos)
        elif opcao == '3':
            alterar_aluno(alunos)
        elif opcao == '4':
            excluir_aluno(alunos)
        elif opcao == '5':
            print("Saindo...")
            break
        else:
            print("Opção inválida. Tente novamente.\n")

if __name__ == '__main__':
    menu()
