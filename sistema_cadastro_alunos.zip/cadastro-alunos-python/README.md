# Sistema de Cadastro de Alunos em Python

Este é um sistema simples de cadastro de alunos feito em Python, com persistência de dados em arquivo JSON e interface via terminal.

## ✅ Funcionalidades

- Incluir aluno
- Listar alunos
- Alterar aluno
- Excluir aluno
- Salvar e carregar dados automaticamente em `alunos.json`

## 💾 Requisitos

- Python 3 instalado

## 🚀 Como executar

1. Clone o repositório:
   ```bash
   git clone https://github.com/igorfranca-dev/cadastro-alunos-python.git
   cd cadastro-alunos-python
   ```

2. (Opcional) Crie um ambiente virtual:
   ```bash
   python -m venv venv
   source venv/bin/activate  # Linux/macOS
   venv\Scripts\activate   # Windows
   ```

3. Execute o sistema:
   ```bash
   python main.py
   ```

## 📁 Arquivos

- `main.py` — código principal do sistema
- `alunos.json` — base de dados em formato JSON
- `README.md` — este arquivo de instruções

---

Sistema desenvolvido como trabalho individual para a disciplina de Desenvolvimento Rápido em Python.
